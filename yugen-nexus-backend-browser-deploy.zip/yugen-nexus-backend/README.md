# YŪGEN NEXUS — Backend untuk deploy lewat browser HP

Backend ini menyediakan proxy AM Search agar browser frontend tidak perlu memanggil API NexaDev langsung.

## File
- `server.js`: Express API, validasi URL video, timeout, rate limit, CORS, dan endpoint health.
- `package.json`: dependensi dan perintah start.
- `render.yaml`: konfigurasi deploy Render.
- `index.html`: salinan frontend yang disertakan sebagai file proyek; AM Search perlu diarahkan ke URL backend setelah deploy (lihat langkah di bawah).

## Endpoint
- `GET /health` — cek layanan.
- `POST /api/ampreset` dengan JSON `{"url":"https://www.youtube.com/watch?v=..."}` — meneruskan permintaan ke NexaDev AM Search.

## Deploy via browser HP
1. Buat repository baru di GitHub, misalnya `yugen-nexus-backend`.
2. Pilih **Add file → Upload files**, unggah `server.js`, `package.json`, dan `render.yaml`. Jangan unggah `index.html` ke root backend jika ingin frontend tetap di hosting terpisah.
3. Buka Render.com melalui browser dan login dengan GitHub.
4. Pilih **New + → Web Service**, pilih repository tadi, lalu buat service.
5. Pastikan Build Command `npm install`, Start Command `npm start`, dan Health Check Path `/health`.
6. Setelah status Live, buka `https://NAMA-SERVICE.onrender.com/health`. Harus muncul JSON `ok: true`.
7. Salin URL service. Di frontend, endpoint AM Search harus diarahkan ke `POST https://NAMA-SERVICE.onrender.com/api/ampreset` dengan body JSON `{"url": videoUrl}`. Contoh kode fetch ada di bawah.

## Kode fetch untuk AM Search
Ganti bagian fetch langsung ke `https://api.nexadev.my.id/api/ampreset?...` pada handler AM Search dengan:
```js
const response = await fetch('https://NAMA-SERVICE.onrender.com/api/ampreset', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
  body: JSON.stringify({ url: videoUrl }),
  signal: controller.signal,
  cache: 'no-store'
});
const rawBody = await response.text();
let data;
try { data = JSON.parse(rawBody); }
catch { throw new Error('Backend tidak mengembalikan JSON valid.'); }
if (!response.ok || data?.ok === false || data?.error) {
  throw new Error(data?.error || data?.message || `HTTP ${response.status}`);
}
```
Ganti `NAMA-SERVICE` dengan nama service Render yang sebenarnya.

## Catatan penting
- Jangan menaruh API secret atau password di frontend.
- `ALLOWED_ORIGINS` default `*` supaya mudah uji coba. Setelah frontend punya URL tetap, atur environment variable `ALLOWED_ORIGINS` di Render ke origin frontend, misalnya `https://nama-frontend.vercel.app` (tanpa path).
- Backend ini hanya mem-proxy AM Search. Endpoint pengiriman NGL tidak diproxy; fitur pengiriman massal/spam tidak disediakan.
- Ini belum mengubah otomatis kode AM Search di `index.html`; lakukan penggantian fetch sesuai contoh di atas setelah URL Render tersedia.
